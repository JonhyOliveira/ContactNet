package exceptions;
//Throws this exception when a certain user is not a subscriber of a certain group
public class SubscriptionNotExists extends Throwable {
}
