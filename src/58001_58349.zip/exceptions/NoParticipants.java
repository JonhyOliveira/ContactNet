package exceptions;
//Throws this exception when there are no participants on a group
public class NoParticipants extends Throwable {
}
