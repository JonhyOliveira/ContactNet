package exceptions;
//Throws this exception when a certain user1 is trying to remove a contacts but the user he is trying to remove is himself
public class ContactNotRemoved extends Throwable {
}
