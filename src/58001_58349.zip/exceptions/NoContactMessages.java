package exceptions;
//Throws this exception when a certain user has no messages shared with another user
public class NoContactMessages extends Throwable {
}
