package exceptions;
//Throws this exception when a user that is trying to be accessed does not exist
public class UserNotExists extends Throwable {
}
