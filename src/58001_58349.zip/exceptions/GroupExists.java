package exceptions;
//Throws this exception when a group that supposedly did not exist, exists
public class GroupExists extends Throwable {
}
