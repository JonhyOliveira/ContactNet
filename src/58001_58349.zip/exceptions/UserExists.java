package exceptions;

public class UserExists extends Throwable {
}
