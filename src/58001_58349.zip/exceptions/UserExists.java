package exceptions;
//Throws this exception when a user exists but the action that was called needs the user to not be created yet
public class UserExists extends Throwable {
}
