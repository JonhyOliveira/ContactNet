package exceptions;

public class SubscriptionNotExists extends Throwable {
}
