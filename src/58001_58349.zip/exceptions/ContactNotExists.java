package exceptions;
//Throws this exception when a certain user that supposedly exists, does not exist
public class ContactNotExists extends Throwable {
}
