package exceptions;
//Throws this exception when a certain user has no contacts
public class NoContacts extends Throwable {
}
