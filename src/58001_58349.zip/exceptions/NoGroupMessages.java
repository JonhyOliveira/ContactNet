package exceptions;
//Throws this exception when there are no messages registered on a certain group
public class NoGroupMessages extends Throwable {
}
