package exceptions;
//Throws this exception when a certain user that supposedly does not exist, already exists
public class ContactExists extends Throwable {
}
