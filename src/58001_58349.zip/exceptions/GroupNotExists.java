package exceptions;
//Throws this exception when a certain group that is trying to be used for something does not exist 
public class GroupNotExists extends Throwable {
}
