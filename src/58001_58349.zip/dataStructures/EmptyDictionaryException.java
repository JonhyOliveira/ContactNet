package dataStructures;

public class EmptyDictionaryException extends Throwable{
}
