package exceptions;

public class NoGroupMessages extends Throwable {
}
