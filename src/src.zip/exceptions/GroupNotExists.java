package exceptions;

public class GroupNotExists extends Throwable {
}
