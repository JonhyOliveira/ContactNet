package exceptions;

public class UserNotExists extends Throwable {
}
