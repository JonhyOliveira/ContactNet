package exceptions;

public class ContactExists extends Throwable {
}
