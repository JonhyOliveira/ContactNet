package exceptions;

public class ContactNotExists extends Throwable {
}
