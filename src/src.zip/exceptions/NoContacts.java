package exceptions;

public class NoContacts extends Throwable {
}
