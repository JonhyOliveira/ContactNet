package exceptions;

public class NoParticipants extends Throwable {
}
