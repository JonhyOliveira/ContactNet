package exceptions;

public class SubscriptionExists extends Throwable {
}
