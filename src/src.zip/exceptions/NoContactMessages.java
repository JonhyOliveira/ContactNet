package exceptions;

public class NoContactMessages extends Throwable {
}
