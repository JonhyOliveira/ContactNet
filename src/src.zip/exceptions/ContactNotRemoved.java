package exceptions;

public class ContactNotRemoved extends Throwable {
}
