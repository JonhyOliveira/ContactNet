package exceptions;

public class GroupExists extends Throwable {
}
